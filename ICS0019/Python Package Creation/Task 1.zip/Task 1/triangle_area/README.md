# Triangle Area Calculation Package

## This module is designed to easily calculate the triangle area

To do this, use the function triangle_area(b, h)
![Triangle Picture](https://www.mathsisfun.com/geometry/images/triangle-b-h.svg)

Put in it the values of __height h__ and __base b__

> Values must be integers or floats.
> Values must be greater than 0.
